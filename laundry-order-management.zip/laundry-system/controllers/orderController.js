// controllers/orderController.js

const { v4: uuidv4 } = require('uuid');
const { orders, PRICES, STATUSES } = require('../models/orderStore');
const { calculateBill, getEstimatedDelivery, isValidPhone } = require('../utils/helpers');

// POST /orders — Create a new order
function createOrder(req, res) {
  const { customerName, phoneNumber, garments } = req.body;

  // --- Validation ---
  if (!customerName || typeof customerName !== 'string' || !customerName.trim()) {
    return res.status(400).json({ error: 'customerName is required.' });
  }
  if (!phoneNumber || !isValidPhone(phoneNumber)) {
    return res.status(400).json({ error: 'A valid phoneNumber is required (7–15 digits).' });
  }
  if (!Array.isArray(garments) || garments.length === 0) {
    return res.status(400).json({ error: 'garments must be a non-empty array.' });
  }

  // Validate each garment
  for (const g of garments) {
    if (!g.type || typeof g.type !== 'string') {
      return res.status(400).json({ error: 'Each garment must have a "type" string.' });
    }
    if (!g.quantity || typeof g.quantity !== 'number' || g.quantity < 1) {
      return res.status(400).json({ error: `Garment "${g.type}" must have a numeric quantity >= 1.` });
    }
    if (!(g.type.toLowerCase() in PRICES)) {
      return res.status(400).json({
        error: `Unknown garment type: "${g.type}". Supported: ${Object.keys(PRICES).join(', ')}.`,
      });
    }
  }

  const totalBill = calculateBill(garments);
  const orderId = uuidv4();
  const now = new Date().toISOString();

  const newOrder = {
    orderId,
    customerName: customerName.trim(),
    phoneNumber: String(phoneNumber).trim(),
    garments: garments.map((g) => ({
      type: g.type.toLowerCase(),
      quantity: g.quantity,
      pricePerItem: PRICES[g.type.toLowerCase()],
      subtotal: PRICES[g.type.toLowerCase()] * g.quantity,
    })),
    totalBill,
    status: 'RECEIVED',
    estimatedDelivery: getEstimatedDelivery(),
    createdAt: now,
    updatedAt: now,
  };

  orders.push(newOrder);

  return res.status(201).json({
    message: 'Order created successfully.',
    orderId: newOrder.orderId,
    totalBill: newOrder.totalBill,
    estimatedDelivery: newOrder.estimatedDelivery,
    order: newOrder,
  });
}

// PUT /orders/:id/status — Update order status
function updateStatus(req, res) {
  const { id } = req.params;
  const { status } = req.body;

  if (!status) {
    return res.status(400).json({ error: 'status is required in request body.' });
  }

  const upperStatus = status.toUpperCase();
  if (!STATUSES.includes(upperStatus)) {
    return res.status(400).json({
      error: `Invalid status. Must be one of: ${STATUSES.join(', ')}.`,
    });
  }

  const order = orders.find((o) => o.orderId === id);
  if (!order) {
    return res.status(404).json({ error: `Order with ID "${id}" not found.` });
  }

  const currentIndex = STATUSES.indexOf(order.status);
  const newIndex = STATUSES.indexOf(upperStatus);

  // Allow backward updates only with a warning, not a block — store owner may need flexibility
  order.status = upperStatus;
  order.updatedAt = new Date().toISOString();

  return res.json({
    message: `Order status updated to ${upperStatus}.`,
    orderId: order.orderId,
    status: order.status,
    updatedAt: order.updatedAt,
    note: newIndex < currentIndex ? 'Status moved backward — confirm this is intentional.' : undefined,
  });
}

// GET /orders — List orders with optional filters
function getOrders(req, res) {
  const { status, customerName, phoneNumber, garmentType } = req.query;

  let result = [...orders];

  if (status) {
    const upperStatus = status.toUpperCase();
    if (!STATUSES.includes(upperStatus)) {
      return res.status(400).json({ error: `Invalid status filter. Must be one of: ${STATUSES.join(', ')}.` });
    }
    result = result.filter((o) => o.status === upperStatus);
  }

  if (customerName) {
    const search = customerName.toLowerCase();
    result = result.filter((o) => o.customerName.toLowerCase().includes(search));
  }

  if (phoneNumber) {
    result = result.filter((o) => o.phoneNumber.includes(String(phoneNumber)));
  }

  if (garmentType) {
    const searchType = garmentType.toLowerCase();
    result = result.filter((o) => o.garments.some((g) => g.type.includes(searchType)));
  }

  return res.json({
    total: result.length,
    orders: result,
  });
}

// GET /orders/:id — Get single order
function getOrderById(req, res) {
  const { id } = req.params;
  const order = orders.find((o) => o.orderId === id);
  if (!order) {
    return res.status(404).json({ error: `Order with ID "${id}" not found.` });
  }
  return res.json(order);
}

// GET /dashboard — Summary stats
function getDashboard(req, res) {
  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalBill, 0);

  const ordersByStatus = STATUSES.reduce((acc, s) => {
    acc[s] = orders.filter((o) => o.status === s).length;
    return acc;
  }, {});

  const recentOrders = [...orders]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5)
    .map(({ orderId, customerName, totalBill, status, createdAt }) => ({
      orderId,
      customerName,
      totalBill,
      status,
      createdAt,
    }));

  const popularGarments = {};
  orders.forEach((o) => {
    o.garments.forEach((g) => {
      popularGarments[g.type] = (popularGarments[g.type] || 0) + g.quantity;
    });
  });

  return res.json({
    totalOrders,
    totalRevenue,
    ordersByStatus,
    recentOrders,
    popularGarments,
    averageOrderValue: totalOrders > 0 ? +(totalRevenue / totalOrders).toFixed(2) : 0,
  });
}

// GET /prices — Return price list
function getPrices(req, res) {
  return res.json({ prices: PRICES });
}

module.exports = { createOrder, updateStatus, getOrders, getOrderById, getDashboard, getPrices };
