// models/orderStore.js
// In-memory storage for orders

const orders = [];

const PRICES = {
  shirt: 10,
  pants: 15,
  saree: 20,
  jacket: 25,
  suit: 40,
  kurta: 12,
  lehenga: 35,
  blouse: 8,
};

const STATUSES = ['RECEIVED', 'PROCESSING', 'READY', 'DELIVERED'];

module.exports = { orders, PRICES, STATUSES };
