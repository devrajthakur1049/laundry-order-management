// utils/helpers.js

const { PRICES } = require('../models/orderStore');

/**
 * Calculate total bill for given garments array
 * @param {Array} garments - [{type, quantity}]
 * @returns {number} totalBill
 */
function calculateBill(garments) {
  return garments.reduce((total, item) => {
    const pricePerItem = PRICES[item.type.toLowerCase()] || 0;
    return total + pricePerItem * item.quantity;
  }, 0);
}

/**
 * Calculate estimated delivery date (3 days from now)
 * @returns {string} ISO date string
 */
function getEstimatedDelivery() {
  const date = new Date();
  date.setDate(date.getDate() + 3);
  return date.toISOString().split('T')[0]; // YYYY-MM-DD
}

/**
 * Validate phone number (basic: 10 digits)
 * @param {string} phone
 * @returns {boolean}
 */
function isValidPhone(phone) {
  return /^\d{7,15}$/.test(String(phone).replace(/[\s\-\+]/g, ''));
}

module.exports = { calculateBill, getEstimatedDelivery, isValidPhone };
