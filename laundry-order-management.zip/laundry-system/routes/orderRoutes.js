// routes/orderRoutes.js

const express = require('express');
const router = express.Router();
const {
  createOrder,
  updateStatus,
  getOrders,
  getOrderById,
  getDashboard,
  getPrices,
} = require('../controllers/orderController');

router.post('/orders', createOrder);
router.put('/orders/:id/status', updateStatus);
router.get('/orders', getOrders);
router.get('/orders/:id', getOrderById);
router.get('/dashboard', getDashboard);
router.get('/prices', getPrices);

module.exports = router;
